/* AMazeBot 2012 Sample Bot
 *
 * This is a starting point for the Amazebot 2012 competition.
 * The source file shows the basic functionality of the major methods
 * in the Amazebot API.
 *
 * Read through the documentation to get a better understanding of the
 * program. See http://amazebot.mohawkcollege.ca/
 *
 * Original developed by C. Mark Yendt (Mohawk College, Jan 2005)
 * Updated by Aravin Duraikannan (Mohawk College, Dec 2012)
 *
 */
// Your class must exist in a package that is the public name of
// your bot (for example in the competition it would be your
// assigned ID, like AMB10_042). Your package must in turn exist
// inside the bots package to be recognized by the system.
// In NetBeans or Eclipse you can use the Refactor command to easily
// change this.
/**
 * Program : Lab1B
 * Name Djura Djurickovic 000140392
 * Date: Feb 1 2012
 * Purpose : The purpose of this program is for the amazbot to find the goal
 * Authorship : I, Djura Djurickovic 000140392 certify that this material is my original work.
 * No other person's work has been used without due acknowledgement.
 */
package bots.SampleBot;

// The following imports are required.
import amazebot2012.*;
import amazebot2012.BotInterface.*;

// These are optional, depending on your needs.
import static amazebot2012.utils.PointHelper.*;
import java.awt.Point;

// Your primary class must be named Brain and must implement BrainInterface.
// You are free to create other classes in other source files if you need.
// Since each Brain exists in its own package, there will never be conflicts.
public class Brain implements BrainInterface {

    BotInterface bot;		// A reference to a bot that your brain will control.
    Point goal;		// Coordinates of the top-left cell of the 4x4 goal room.
    Point mazesize;	// Dimensions of the maze.
    Point startpos;	// Coordinates of the bot's starting position.
    Compass startdir;	// Direction in which the bot faces at start.

    //--------------------------------------------------------------------------
    // REQUIRED METHOD: So the system can find out your preferred alias.
    // This name is used in the competition, so make it fun. Don't forget
    // to provide a nice icon too.
    @Override
    public String getName() {
        return "Clever Name";
    }

    //--------------------------------------------------------------------------
    // REQUIRED METHOD: The system will hand you a bot, and your code will operate it.
    @Override
    public void runBot(BotInterface inbot) {
        bot = inbot;

        // Determine the dimensions of the maze. In this competition the size
        // is fixed at 44 by 44 cells, which is what this method will return.
        // So you could hardcode it, but it's generally better to programmatically
        // discover such things. Note that cell coordinates range from 0 to 43.
        mazesize = bot.getMazeSize();

        // Determine the location of the goal room. The goal room is always
        // 4 by 4 cells. This method gives you the top-left cell of the goal room.
        goal = bot.getGoalCorner();

        // Get the starting position and direction.
        startpos = bot.getStartPosition();
        startdir = bot.getStartDirection();

        // You can log diagnostic information to your bot's log file (contained
        // in the "logs/" folder; in this case the file is "SampleBot_errors.log".
        // As the filename indicates, this is primarily for tracking errors--any
        // unhandled exceptions in your code will be logged to this file. But you
        // can output any diagnostic information to assist in debugging.

        // The log is appended to, so if you do a batch you can review all the
        // messages generated over the whole batch. However when you are working
        // in the IDE, it is more convenient for the log to be overwritten, so
        // you can keep the file open in an editor and not have to keep scrolling
        // down. This command will clear the log file only in developer mode.
        bot.clearLog();

        // You should always use the bot's print statements rather than the
        // ones in System.out. This will log the message to both the file and
        // to the console.
        bot.println("SampleBot about to start running...");

        // Every bot program has this main loop. Note that this is an infinite loop,
        // but that's ok because once your bot reaches the goal, runs out of energy,
        // or crashes the system will automatically exit your code.
        while (true) {
            // Inside the loop you can put any statements you wish. Each call to
            // one of the bot control methods will cost energy (there are a handful
            // of other methods which are free, but they don't control the bot).


            Point now = bot.getPosition();

            if (bot.move(MOVE.FORWARD) == false) ///turn move and look
            {
                bot.turn(TURN.RIGHT);
            }

            if (now.x == goal.x) {
                bot.turn(TURN.RIGHT);
            }

            if (now.y == goal.y) {
                bot.turn(TURN.LEFT);
            }
            bot.getNextPosition();




        }
    }

    //--------------------------------------------------------------------------
    // EXTRA! The Compass is a useful convenience class. Please use it for all your
    // directional needs! We already used it to find out the bot's starting direction,
    // and you can use it to keep track of which way your bot is pointing. It has
    // methods covering all the important operations.
    private void funWithCompasses() {
        Compass c = Compass.EAST;	// Let's create a new compass and make it point EAST.

        // To turn the compass you have to reassign (that's just the way Java's enums work):
        c = c.getRight();		// Result is Compass.SOUTH.

        // You can get the unit vector equivalent to this direction:
        Point vector = c.getVector();

        // What's the vector useful for? Well suppose you have the bot's current position, and
        // you want to know what the position would be if it were to move in a particular direction.

        Point pos = bot.getPosition();		// Note that this is not a free method!

        // You can use a method provided by the PointHelper class (which has been statically
        // imported so you don't have to use the class name here) to easily add the points:
        Point nextpos = addPoints(pos, vector);

        // Say, wouldn't it be nice if Java had operator overloading? Yeah.

        // You can also perform a specified number of 90-degree turns:
        // Positive values are right turns, negative values are left turns.
        c = c.plus(2);		// Result is Compass.NORTH.

        // Often you want to find the opposite direction and that is done thusly:
        c = c.getOpposite();		// Result is Compass.SOUTH again.

        // Or when you need to compare 2 directions you can do it like this:

        // Find how many 90-degree turns are needed to change direction from WEST to whatever c is facing:
        int turns = c.getTurnsFrom(Compass.WEST);	// Result is -1.

        // Or you can go the other way, whatever is most intuitive for you:
        turns = c.getTurnsTo(Compass.EAST);			// Result is 2.
    }
}
