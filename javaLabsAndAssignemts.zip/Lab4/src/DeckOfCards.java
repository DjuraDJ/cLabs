/**
 * Program : Lab 4 DeckOfCards.java 
 * Date : Thurs. March 22 2012 
 * Purpose : This was a poker game originally but was switched to a Black jack game 
 * Copyright I, Djura Djurickovic  000140392 certify that this material is my original work. No other
 * person's work has been used without due acknowledgement.
 */
import java.util.ArrayList;
import java.util.Random;
/**
 * 
 * @author Djura Djurickovic 000140392
 */
public class DeckOfCards {
// faces array of type string has all the face values of the cards
    String faces[] = {"Ace", "Deuce", "Three", "Four", "Five", "Six",
        "Seven", "Eight", "Nine", "Ten", "Jack", "Queen", "King"};
    String suits[] = {"Hearts", "Diamonds", "Clubs", "Spades"};  // array of type string has the suit values of cards
    private Card deck[]; // array of Card objects
    private int currentCard; // the index of next Card to be dealt
    private final int NUMBER_OF_CARDS = 52; // constant number of cards
    private Random randomNumbers; // random number generator

    // constructor fills deck of cards
    /**
     * 
     * @param numberOfDecks of Int
     */
    public DeckOfCards(int numberOfDecks) {
        deck = new Card[NUMBER_OF_CARDS * numberOfDecks]; // create array of Card objects
        currentCard = 0; // initialize currentCard 
        randomNumbers = new Random(); // create random number generator

        // populate deck with Card objects
        for (int count = 0, cardOfDeck = 0; count < deck.length; count++, cardOfDeck++) {
            deck[ count] =
                    new Card(faces[ cardOfDeck % 13], suits[ cardOfDeck / 13]);
            // if the card deck is 52 sub. one from deck to get 51. it compensate for the zero in the begining of the array
            if (cardOfDeck == 51) {
                cardOfDeck = -1;
            }
        }
    } // end DeckOfCards constructor

    // shuffle deck of cards with one-pass algorithm

    public void shuffle() {
        currentCard = 0; // reinitialize currentCard

        // for each card, pick another random card and swap them
        for (int first = 0; first < deck.length; first++) {
            int second = randomNumbers.nextInt(NUMBER_OF_CARDS);
            Card temp = deck[ first];
            deck[ first] = deck[ second];
            deck[ second] = temp;
        } // end for
    } // end method shuffle

    // deal one card
    /**
     * 
     * @return null
     */
    public Card dealCard() {
        // determine whether cards remain to be dealt
        if (currentCard < deck.length) {
            return deck[ currentCard++]; // return current Card in array
        } else {
            return null; // return null to indicate that all cards were dealt
        }
    } // end method dealCard

    /**
     * 
     * @param hand is ArrayList of type Card
     * @return  array of numbers of type int
     */
        // tally the number of each face card in hand
    private int[] totalHand(ArrayList<Card> hand) {
        int numbers[] = new int[faces.length]; // store number of face

        // initialize all elements of numbers[] to zero
        for (int i = 0; i < 13; i++) {
            numbers[ i] = 0;
        }

        // compare each card in the hand to each element in the faces array
        for (int h = 0; h < hand.size(); h++) {
            for (int f = 0; f < 13; f++) {
                if (hand.get(h).getFace().equals(faces[f])) {
                    ++numbers[ f];
                }
            } // end for
        } // end for

        return numbers;
    } // end method totalHand
/**
 * 
 * @param hand arrayList of type card 
 * @return handtotal of type Int
 */
    public int handValue(ArrayList<Card> hand) {
        int handTotal = 0;
        int cardCount[] = new int[faces.length];
        cardCount = totalHand(hand);

        //loops throw cardcount i reps. the value at each itteration 
        int indexOfcardCount = 0;
        for (int i : cardCount) {
            //if value @ index is > 0 
            if (i > 0) {
                // then 1 cardCount[1]
                // gives the value to all the suits cards from 1 to 10
                // Kings Queens Jacks have value of 10 Aces have value of 11 or 1 depends on the cards in hand
                switch (indexOfcardCount) {
                    case 0:
                        handTotal = handTotal + 11 * i;
                        break;
                    case 1:
                        handTotal = handTotal + (indexOfcardCount + 1) * i;
                        break;
                    case 2:
                        handTotal = handTotal + (indexOfcardCount + 1) * i;
                        break;
                    case 3:
                        handTotal = handTotal + (indexOfcardCount + 1) * i;
                        break;
                    case 4:
                        handTotal = handTotal + (indexOfcardCount + 1) * i;
                        break;
                    case 5:
                        handTotal = handTotal + (indexOfcardCount + 1) * i;
                        break;
                    case 6:
                        handTotal = handTotal + (indexOfcardCount + 1) * i;
                        break;
                    case 7:
                        handTotal = handTotal + (indexOfcardCount + 1) * i;
                        break;
                    case 8:
                        handTotal = handTotal + (indexOfcardCount + 1) * i;
                        break;
                    case 9:
                        handTotal = handTotal + (indexOfcardCount + 1) * i;
                        break;
                    case 10:
                        handTotal = handTotal + 10 * i;
                        break;
                    case 11:
                        handTotal = handTotal + 10 * i;
                        break;
                    case 12:
                        handTotal = handTotal + 10 * i;
                        break;
                }

            }
            indexOfcardCount++; // keeps total of cards
        }
/** checks to see if Aces is greater then 21 and if it is an Aces 
 *  if so subtraction is used to determinants if Aces are 1 or 11 
 */
        if (handTotal > 21 && cardCount[0] > 0) {
            for (int i = 0; i < cardCount[0]; i++) {
                if (handTotal > 21) {
                    handTotal -= 10;
                } else {
                    break;
                }
            }
        }

        return handTotal;
    }
 
} // end class DeckOfCards
/**************************************************************************
 * (C) Copyright 1992-2007 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
