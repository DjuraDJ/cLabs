/**
 * Program: Cab Fair
 * program: Main.java
 * Date: March 8 2012
 * Purpose: The purpose of this program is to calculate the total amount of 
 * total fair my determining the weight distance time traveled  and with witch 
 * cab used 1111 or 2222 
 * I, Djura Djurickovic  certify that this material is my original work. 
 * No other person's work has been used without due acknowledgement.
 */
package lab3;

//import java.util.Scanner;
import java.util.Scanner;


public class main {

    public static void main(String[] args) {
        int cabNumbers;
        double passengerWeight;
        boolean frontSeat;
        int numberOfMinutes;

        Cab firstCab = new Cab(1111);
        Cab secondCab = new Cab(2222);
        Scanner scan = new Scanner(System.in);
     /**
      *  if user has to enter valid cab info  1111 or 2222 or it will exit the loop 
      */
        do {
            System.out.print("CabID (1111 or 2222): ");
            cabNumbers = scan.nextInt();

            if (cabNumbers == 1111 || cabNumbers == 2222) {
                int frontSeatAsInt;

                System.out.print("Passenger Weight: ");
                passengerWeight = scan.nextDouble();
                /**
                 *  determines  if user is sitting in front or back seat
                 */
                System.out.print("Sitting in front seat (1 = Yes, 0 = No): ");
                frontSeatAsInt = scan.nextInt();
                if (frontSeatAsInt == 1) {
                    frontSeat = true;
                } else {
                    frontSeat = false; 
                }

                if (cabNumbers == 1111) {
                    firstCab.pickUp(passengerWeight, frontSeat);
                } else {
                    secondCab.pickUp(passengerWeight, frontSeat);
                }

                System.out.print("How many minutes: ");
                numberOfMinutes = scan.nextInt();

                if (cabNumbers == 1111) {
                    firstCab.dropOff(numberOfMinutes);
                } else {
                    secondCab.dropOff(numberOfMinutes);
                }
            }
        } while (cabNumbers == 1111 || cabNumbers == 2222);
        /**
         * Prints end of a shift total for cab 1111 & 2222
         * prints the total of cab and total of company 
         */
        firstCab.EndOfShift();
        secondCab.EndOfShift();
        firstCab.displayStats();
        secondCab.displayStats();

    }
}
