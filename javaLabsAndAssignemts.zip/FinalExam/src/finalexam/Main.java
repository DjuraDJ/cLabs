/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package finalexam;

/**
 *
 * @author Djura Djurickovic
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      String inline = "AbcdA-Zy";
      int count = 0;
      
        if("A-Z".equals(inline) ){
            count++;
        }
        
            
                System.out.printf("%d \n",count);
       }
    }

