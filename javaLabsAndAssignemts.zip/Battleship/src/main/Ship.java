/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

/**
 *
 * @author Djura Djurickovic
 */
public class Ship {

    private String ShipName;
    public int ShipSize;
    public int ShipHits;

  /**
   * 
   * @param size of int 
   */
    public Ship(int size) {
        ShipSize = size;
       
        if (ShipSize == 5) {
            ShipName = "Aircraft";
        } else if (ShipSize == 4) {
            ShipName = "BattleShip";
        } else if (ShipSize == 3) {
            ShipName = "Submirine";
        } else if (ShipSize == 2) {
            ShipName = "Pt Boat";
        }
        
        System.out.println("I Lanched my " + ShipName);
    }
    /**
     * 
     * @return shipName
     */
    public String getname(){
        return ShipName;
    }
    
    public void fire(){
        String salvo = (ShipHits > 0) ? "again":"";
        ShipHits++;
        
        System.out.printf("You hit %s%s!\n",getname() ,salvo);
        
        if(ShipHits == ShipSize){
            System.out.println("You sunk my "+ getname()+"!");
        }
    }
}
