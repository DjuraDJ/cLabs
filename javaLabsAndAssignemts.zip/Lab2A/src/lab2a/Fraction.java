    /*
Program : Fraction.Java
 * Date Feb 15 2012
 * Purpose : Find a Numerator and Denominator of two fraction and then Add
 * the two fraction
 * CopyRight:   I Djura Djurickovic 000140392 certify that this
material is my original work.
No other person's work has been used without suitable acknowledgment and
I have not made my work available to anyone else."

 */
package lab2a;


public class Fraction {

    private int numerator;
    private int denominator;
// constructor created
    public Fraction(int num, int denom) {
        numerator = num;
        denominator = denom;

        reduce(); // reduce is called to reduce variables in to gcd

    }

    public void display() {
        System.out.printf("%d / %d\n", numerator, denominator);
    }

    public Fraction add(Fraction rhs) {
        int multipleOfDenom, newNumer1, newNumer2;
        int sumOfNumerators;
        Fraction sumOfFractions;
       // finds lowest comman denominator and multiplys the left hand side
        //by the right hand side
        multipleOfDenom = this.getDenominator() * rhs.getDenominator();
        /*
         * mulitplication of left hand side with right hands side of  numerator
         * denominator  to get a new numerator
         */
        newNumer1 = this.getNumerator() * rhs.getDenominator();
        newNumer2 = this.getDenominator() * rhs.getNumerator();

        sumOfNumerators = newNumer1 + newNumer2; // add the two numerators
        // pass sum of numerator and multi of denom  throw the method
        sumOfFractions = new Fraction(sumOfNumerators, multipleOfDenom);

        return sumOfFractions;

    }

    public int getNumerator() {
        return numerator;
    }

    public int getDenominator() {
        return denominator;
    }

    private void reduce() {
        int gcd = findGCD(); //assigns GCD() to variable so they can be divide
        numerator = numerator / gcd;
        denominator = denominator / gcd;
    }

    private int findGCD() {
        int gcd = 0;
        int smallNum = 0;
        int bigNum = 0;
        int remainder = 0;
        // determinds if numerator is greater or denominator is
        //greater and assigns the two to the variables
        if (numerator > denominator) {
            smallNum = denominator;
            bigNum = numerator;
        } else {
            smallNum = numerator; 
            bigNum = denominator; 
        }

        /*
         * takes the big number and mod it by small number then checks to see if
         * its equal to 0.
         * Then finds the remainder assigns the small number to the big number.
         * assigns the remainder to small number. This is done until GCD is reached
         */
        while (bigNum % smallNum != 0) {            
            remainder = bigNum % smallNum; 
            bigNum = smallNum; 
            smallNum = remainder; 
        }

        gcd = smallNum; // assigns gcd

        return gcd;  // returns gcd
    }
}
