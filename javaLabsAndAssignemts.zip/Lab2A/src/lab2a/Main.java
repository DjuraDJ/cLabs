    /*
Program : Main.Java
 * Date Feb 15 2012
 * Purpose : Find a Numerator and Denominator of two fraction and then Add
 * the two fraction
 * CopyRight:   I Djura Djurickovic 000140392 certify that this
material is my original work.
No other person's work has been used without suitable acknowledgment and
I have not made my work available to anyone else."

 */
package lab2a;

import java.util.Scanner;


public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Variable decloration
        Fraction fraction1, fraction2, sumOfFractions;
        int numer1, numer2, denom1, denom2;
        Scanner scan = new Scanner(System.in);
// get from user input Numerator and denominator of two fractions
        System.out.print("First numerator: ");
        numer1 = scan.nextInt();
        System.out.print("First denominator: ");
        denom1 = scan.nextInt();
// if user enter a zero value it ask for another denominator
        while (denom1 <= 0) {
            System.out.print("First denominator: ");
            denom1 = scan.nextInt();
        }

        System.out.print("Second numerator: ");
        numer2 = scan.nextInt();
        System.out.print("Second denominator: ");
        denom2 = scan.nextInt();

        while (denom2 <= 0) {
            System.out.print("Second denominator: ");
            denom2 = scan.nextInt();
        }

        fraction1 = new Fraction(numer1, denom1);
        fraction2 = new Fraction(numer2, denom2);
// displays the fractions
        fraction1.display();
        fraction2.display();
// add the 2 fractions
        System.out.println("sum of the two fractions is");
        sumOfFractions = fraction1.add(fraction2);
// displays the sum of the fractions
        sumOfFractions.display();
    }
}
