/**
 * File Name: Munge.java
 * Purpose: The Purpose of this program is to take a file  open a file, 
 * read each of the records from the file, use that data to populate a 
 * two dimensional array and write the sorted data out to a new text file.
 * Files: input.txt & output.txt
 * Date: April 13 2012
 * Author: Djura Djurickovic 000140392
 * Copyright: I Djura Djurickovic, 000140392 certify that this material is my original work. 
 * No other person's work has been used without due acknowledgement.
 */
/**
 *  imports from API
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Formatter;
import java.util.FormatterClosedException;
import java.util.Arrays;
import java.util.NoSuchElementException;

/**
 * 
 * @author Djura Djurickovic
 *  All Try catch are used in this program to catch the error and place a proper error message for the user to see
 *  Open file throw run configurations put file name in command line arguments f:\..\input.txt and f:\..\output.txt.
 */
public class Munge {
    private String inFileName;
    private String outFileName;
    private String[][] provCity = new String[13][16];
    private Formatter outFile;
    private Scanner inFile;
    int countBc = 0;
    int countAlb = 0;
    int countSka = 0;
    int countMnt = 0;         // keeps track of cities in the prov
    int countOnt = 0;
    int countQbc = 0;
    int countNb = 0;
    int countNs = 0;
    int countPei = 0;
    int countNfl = 0;
    int countYk = 0;
    int countNwt = 0;
    int countNunv = 0;
    int numberOfProvRead = 0;
/**
 * 
 * @param inFile of type String
 * @param outFile  of type String
 * puts the name of the Provinces in the array first element
 *  constructor
 */
    public Munge(String inFile, String outFile) {
        inFileName = inFile;
        outFileName = outFile;
        provCity[0][0] = "British Columbia: ";
        provCity[1][0] = "Alberta: ";
        provCity[12][0] = "Nunavut: ";
        provCity[11][0] = "Northwest Territories: ";
        provCity[10][0] = "Yukon: ";
        provCity[9][0] = "Newfoundland and Labrador: ";
        provCity[8][0] = "Prince Edward Island: ";
        provCity[7][0] = "Nova Scotia: ";
        provCity[6][0] = "New Brunswick: ";
        provCity[5][0] = "Quebec: ";
        provCity[4][0] = "Ontario: ";
        provCity[3][0] = "Manitoba: ";
        provCity[2][0] = "Saskatchewan: ";
    }
/**
 *  Opens the file with the scanner Object if error is found user is notified
 */
    public void openFiles() {
        try {
            inFile = new Scanner(new File(inFileName));
        } catch (FileNotFoundException e) {
            System.err.println("Error opening file");
            System.exit(1);
        }
/**
 *  opens output file for writing
 */
        try {
            outFile = new Formatter(outFileName);
        } catch (SecurityException securityException) {
            System.err.println("No permission to write to file");
            System.exit(1);
        } catch (FileNotFoundException e) {
            System.err.println("Error opening file");
            System.exit(1);
        }
    }
/**
 *  creates an String array for all the cities in a province 
 */
    public void readRecords() {
        // cities in a province unsorted
        String[] ontCities = new String[15];
        String[] bcCities = new String[15];
        String[] albCities = new String[15];
        String[] skCities = new String[15];
        String[] mbCities = new String[15];
        String[] qcCities = new String[15];
        String[] nbCities = new String[15];
        String[] nsCities = new String[15];
        String[] nflCities = new String[15];
        String[] peiCities = new String[15];
        String[] ykCities = new String[15];
        String[] nwtCities = new String[15];
        String[] nunCities = new String[15];
        // cities in a province sorted
        String[] ontCitiesSorted;
        String[] bcCitiesSorted;
        String[] albCitiesSorted;
        String[] skCitiesSorted;
        String[] mbCitiesSorted;
        String[] qcCitiesSorted;
        String[] nbCitiesSorted;
        String[] nsCitiesSorted;
        String[] nflCitiesSorted;
        String[] peiCitiesSorted;
        String[] ykCitiesSorted;
        String[] nwtCitiesSorted;
        String[] nunCitiesSorted;

        try {
            while (inFile.hasNext()) {
                String[] tokenizedLine = new String[2];
                int city = 0;
                int province = 1;

                //tokenize the current line on ", "
                tokenizedLine = inFile.nextLine().split(", ");
                // match second token(provence) with 1st element of provCity[*][0]
                //to the ":" not inclucive  

                if (tokenizedLine[province].equals("Ontario")) {
                    ontCities[countOnt++] = tokenizedLine[city];
                } else if (tokenizedLine[province].equals("British Columbia")) {
                    bcCities[countBc++] = tokenizedLine[city];
                } else if (tokenizedLine[province].equals("Alberta")) {
                    albCities[countAlb++] = tokenizedLine[city];
                } else if (tokenizedLine[province].equals("Saskatchewan")) {
                    skCities[countSka++] = tokenizedLine[city];
                } else if (tokenizedLine[province].equals("Manitoba")) {
                    mbCities[countMnt++] = tokenizedLine[city];
                } else if (tokenizedLine[province].equals("Quebec")) {
                    qcCities[countQbc++] = tokenizedLine[city];
                } else if (tokenizedLine[province].equals("New Brunswick")) {
                    nbCities[countNb++] = tokenizedLine[city];
                } else if (tokenizedLine[province].equals("Nova Scotia")) {
                    nsCities[countNs++] = tokenizedLine[city];
                } else if (tokenizedLine[province].equals("Prince Edward Island")) {
                    peiCities[countPei++] = tokenizedLine[city];
                } else if (tokenizedLine[province].equals("Newfoundland and Labrador")) {
                    nflCities[countNfl++] = tokenizedLine[city];
                } else if (tokenizedLine[province].equals("Yukon")) {
                    ykCities[countYk++] = tokenizedLine[city];
                } else if (tokenizedLine[province].equals("Northwest Territories")) {
                    nwtCities[countNwt++] = tokenizedLine[city];
                } else if (tokenizedLine[province].equals("Nunavut")) {
                    nunCities[countNunv++] = tokenizedLine[city];
                }
            }
        } catch (NoSuchElementException elementException) {
            System.err.println("No line was found.");
            System.exit(2);
        }

        ontCitiesSorted = new String[countOnt];
        bcCitiesSorted = new String[countBc];
        albCitiesSorted = new String[countAlb];
        mbCitiesSorted = new String[countMnt];
        skCitiesSorted = new String[countSka];
        nbCitiesSorted = new String[countNb];
        nsCitiesSorted = new String[countNs];
        peiCitiesSorted = new String[countPei];
        nflCitiesSorted = new String[countNfl];
        ykCitiesSorted = new String[countYk];
        nwtCitiesSorted = new String[countNwt];
        nunCitiesSorted = new String[countNunv];
        qcCitiesSorted = new String[countQbc];
        /**
         * Created a method that will cities in order and keep track of the number of cities back to 
         * the main array provCity
         */
        copyToMainArray(bcCities, bcCitiesSorted, countBc);
        copyToMainArray(albCities, albCitiesSorted, countAlb);
        copyToMainArray(skCities, skCitiesSorted, countSka);
        copyToMainArray(mbCities, mbCitiesSorted, countMnt);
        copyToMainArray(ontCities, ontCitiesSorted, countOnt);
        copyToMainArray(qcCities, qcCitiesSorted, countQbc);
        copyToMainArray(nbCities, nbCitiesSorted, countNb);
        copyToMainArray(nsCities, nsCitiesSorted, countNs);
        copyToMainArray(peiCities, peiCitiesSorted, countPei);
        copyToMainArray(nflCities, nflCitiesSorted, countNfl);
        copyToMainArray(ykCities, ykCitiesSorted, countYk);
        copyToMainArray(nwtCities, nwtCitiesSorted, countNwt);
        copyToMainArray(nunCities, nunCitiesSorted, countNunv);
    }
/**
 * 
 * @param citiesUnsorted of type String array
 * @param citiesSorted  of type String array
 * @param cityCount   of type Integer
 */
    private void copyToMainArray(String[] citiesUnsorted, String[] citiesSorted, int cityCount) {
        System.arraycopy(citiesUnsorted, 0, citiesSorted, 0, cityCount);
        Arrays.sort(citiesSorted);
        System.arraycopy(citiesSorted, 0, provCity[numberOfProvRead], 1, cityCount);

        numberOfProvRead++;
    }
/**
 *  write to the output file
 */
    public void writeRecords() {
        try {
            for (int i = 0; i < 13; i++) {
                int countOfCurrentCitysInProv = 0;
                // if provcity[i] check against index 0 of provcity[i
                if (provCity[i][0].equals("Ontario: ")) {
                    if (countOnt == 0) {
                        continue;
                    }
                    countOfCurrentCitysInProv = countOnt;
                } else if (provCity[i][0].equals("British Columbia: ")) {
                    if (countBc == 0) {
                        continue;
                    }
                    countOfCurrentCitysInProv = countBc;
                } else if (provCity[i][0].equals("Alberta: ")) {
                    if (countAlb == 0) {
                        continue;
                    }
                    countOfCurrentCitysInProv = countAlb;
                } else if (provCity[i][0].equals("Saskatchewan: ")) {
                    if (countSka == 0) {
                        continue;
                    }
                    countOfCurrentCitysInProv = countSka;
                } else if (provCity[i][0].equals("Manitoba: ")) {
                    if (countMnt == 0) {
                        continue;
                    }
                    countOfCurrentCitysInProv = countMnt;
                } else if (provCity[i][0].equals("Quebec: ")) {
                    if (countQbc == 0) {
                        continue;
                    }
                    countOfCurrentCitysInProv = countQbc;
                } else if (provCity[i][0].equals("New Brunswick: ")) {
                    if (countNb == 0) {
                        continue;
                    }
                    countOfCurrentCitysInProv = countNb;
                } else if (provCity[i][0].equals("Nova Scotia: ")) {
                    if (countNs == 0) {
                        continue;
                    }
                    countOfCurrentCitysInProv = countNs;
                } else if (provCity[i][0].equals("Prince Edward Island: ")) {
                    if (countPei == 0) {
                        continue;
                    }
                    countOfCurrentCitysInProv = countPei;
                } else if (provCity[i][0].equals("Newfoundland and Labrador: ")) {
                    if (countNfl == 0) {
                        continue;
                    }
                    countOfCurrentCitysInProv = countNfl;
                } else if (provCity[i][0].equals("Yukon: ")) {
                    if (countYk == 0) {
                        continue;
                    }
                    countOfCurrentCitysInProv = countYk;
                } else if (provCity[i][0].equals("Northwest Territories: ")) {
                    if (countNwt == 0) {
                        continue;
                    }
                    countOfCurrentCitysInProv = countNwt;
                } else if (provCity[i][0].equals("Nunavut: ")) {
                    if (countNunv == 0) {
                        continue;
                    }
                    countOfCurrentCitysInProv = countNunv;
                }
                /**
                 * if the count of current cities in province is not 0 then 
                 * write to output. if the count of cities in a province is not 0 then
                 * write cities on the line once reach end put in a new /n so you get the correct out put.
                 */
                if (countOfCurrentCitysInProv != 0) {
                    for (int j = 0; j <= countOfCurrentCitysInProv; j++) {
                        if (j == 0 && i != 0) {
                            outFile.format("%n");
                        }
                        outFile.format(provCity[i][j]);
                        if (j != 0 && j != countOfCurrentCitysInProv) {
                            outFile.format(", ");
                        }
                    }
                }
            }
            /**
             *  catch and error if problems with the file and print error to screen for user to see
             */
        } catch (FormatterClosedException FormatterClosedEx) {
            System.err.println("Error Writing to File");
            System.exit(1);
        }
    }
/**
 *  Close file after it is Done
 */
    public void closeFiles() {
        if (outFile != null) {
        }
        outFile.close();
    }
}
