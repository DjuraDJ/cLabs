/**
 * File : Main.java
 * Purpose: The Purpose of this program is to take a file  open a file, 
 * read each of the records from the file, use that data to populate a 
 * two dimensional array and write the sorted data out to a new text file.
 * Files: input.txt & output.txt
 * Date: April 13 2012
 * Author: Djura Djurickovic 000140392
 * Copyright: I Djura Djurickovic, 000140392 certify that this material is my original work. 
 * No other person's work has been used without due acknowledgement.
 */
public class Main {
/**
 * 
 * @param args of type String[]
 */
    public static void main(String[] args) {
        /**
         * if more then two arguments an error message.
         */
        if (args.length < 2) {
            System.err.println("Usage: java -jar lab5.jar infile outfile");
            System.exit(99);
        }

        Munge dataSorter = new Munge(args[0], args[1]); // takes two arguments input.txt and output.txt
/**
 *  open input file
 * read a input file
 * write to output file
 * close output file
 */
        dataSorter.openFiles();
        dataSorter.readRecords();
        dataSorter.writeRecords();
        dataSorter.closeFiles();
    }
}
