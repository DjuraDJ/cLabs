//I, Djura Djurickovic certify that this material is my original work.
//No other person's work has been used without due acknowledgement.

// The purpose of this program is to create an inventory tracking system
// For various products. Each product has an ID, Name, Company, Cost, and 
// Instock value associated with it.

// The user will user a menu interface that will allow the adding and removal of
// Products, to increase or decrease the current stock of a product, to display
// all items currently in inventory, and the total value of the current stock.

#include <stdio.h>
#include <string>
#include <iomanip>
#include <iostream>
#include <fstream>
#include "product.h"

void print_menu();

int main()
{
  
  char menu;
  product prod[100];
  int prodID = 1, i, input;
  double total = 0;
  string err, file;
  ifstream Inventory;
  
  //Loading file into program at startup
  //Inventory.open("F:\\C++\\Assignment1\\inventory.txt");
  //if (Inventory)
  //{
  //  while(!Inventory.eof())
  //  {      
  //     prod[prodID].prodID = prodID;
  //     Inventory >> prod[prodID].name >> prod[prodID].company >>\
  //     prod[prodID].stock >> prod[prodID].cost;
  //     prodID++;
  //  }
  //}
  do
  {   
   print_menu();
   cin >> menu;
   menu = tolower(menu);
   switch(menu)
   {
     //Add new product
     case 'n':
       system("cls");
       prod[prodID].add(prodID);
       prodID++;
       break;
     
     //Show all products in inventory  
     case 'l':
       system("cls");
       cout << "ID\tName\t\tCompany\t\t\tCost\tStock" << endl;
       cout << "-------------------------------------------------------------" << endl;
       for (i = 1; i < prodID; i++)
       {
         prod[i].list();
       }
       system("PAUSE");
       break;
     
     //Add stock to a product    
     case 'a':
       system("cls");
       cout << "Enter Product ID: ";
       cin >> input;
       for (i = 1; i < prodID; i++)
       {
       if (input == i)
       {
         prod[i].addcopy();
         err = "Inventory Updated"; 
         break;        
       }
       else
          err = "ID not Found";
       }
       cout << err << endl;
       system("PAUSE");
       break;
       
     //Remove stock from a product
     case 'r':
       system("cls");
       cout << "Enter Product ID: ";
       cin >> input;
       for (i = 1; i < prodID; i++)
       {
       if (input == i)
       {
         prod[i].delcopy();
         err = "Inventory Updated";         
         break;
       }
       else
         err = "ID not Found";
       }
       cout << err << endl;
       system("PAUSE");
       break;
       
     //Remove a product completely
     case 'd':
       system("cls");
       cout << "Enter Product ID: ";
       cin >> input;
       for (i = 1; i < prodID; i++)
       {
       if (input == i)
       {
         prod[i].delinv();
         err = "Product Removed";
         break;         
       }
       else
          err = "ID not Found";
       }
       cout << err << endl;
       system("PAUSE");  
       break;
       
       //Calculate the value of current stock
     case 't':
       for (i = 1; i < prodID; i++)
       {
          if (prod[i].prodID > 0)
          {
             total += prod[i].stock * prod[i].cost;
          }
       }
       system("cls");
       cout << "The total value of the current inventory is: $" << total << endl;
       total = 0;
       system("PAUSE");
       break;
     case 'x':
     break;
     
     default:
     cout << "Invalid Entry, Please try again" << endl;
     system("PAUSE");     
   }
   cin.ignore(100,'\n');  
  }while (menu != 'x');
  return 0;
}

//This will print the main menu of the program 
void print_menu()
{
      system("cls");
      cout << endl\
           << "\t***************************************************" << endl\
           << "\t   Software Inventory Management Application" << endl\
           << "\t***************************************************" << endl\
           << "\t[ L ] - List the current inventory"<< endl\
           << "\t[ A ] - Add copies to a products stocks"<< endl\
           << "\t[ T ] - Tabulate the total value of the inventory"<< endl\
           << "\t[ R ] - Remove copies from a products stocks" << endl\
           << "\t[ N ] - Add a new software package to the inventory" << endl\
           << "\t[ D ] - Delete a software package from the inventory" << endl\
           << "\t[ X ] - Exit this program.\n\n" << endl;
      cout << "\tChoice: ";
}
