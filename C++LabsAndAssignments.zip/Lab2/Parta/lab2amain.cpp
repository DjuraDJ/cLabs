//I, Djura Djurickovic, 000199229 certify that this material is my original work. No other person's work has been used without due acknowledgement.

// The purpose of this program is the create customer objects stored in a header
// file. Up to 10 customers may be created at one time. Name, Address, City,
// Postal Code and Account Balance are tracked in this program

// Currently there is minimal validation with the menu itself and checks if
// a customer actually exists. No other validiation is implemented yet.
#include <stdio.h>
#include <string>
#include <iomanip>
#include <iostream>
#include "customer.h"

void print_menu();

int main()
{
  
  char menu;
  customer cust[10];
  int custID = 1, temp;      
  do
  {
   print_menu();
   cin >> menu;
   switch(tolower(menu))
   {
     case 'a':
       system("cls");
       cin.ignore(100,'\n');
       cust[custID].add();
       custID++;                     
       break;
       
     case 's':
       system("cls");
       cout << "CustomerID[1-10]: ";
       cin >> temp;
       if (temp > custID -1)
          {
          cout << "That Customer does not Exist" << endl;          
          }
       else{
          cust[temp].show();  
       }
       system("PAUSE");              
       break;
       
       case 'd':
       system("cls");
       cout << "CustomerID[1-10]: ";
       cin >> temp;
       if (temp > custID -1)
          {
          cout << "That Customer does not Exist" << endl;          
          }
       else{
          cust[temp].deposit();  
       }
       system("PAUSE");
       break;
       
       case 'w':
       system("cls");
       cout << "CustomerID[1-10]: ";
       cin >> temp;
       if (temp > custID -1)
          {
          cout << "That Customer does not Exist" << endl;          
          }
       else{
          cust[temp].withdrawl();  
       }
       system("PAUSE");
       break;       
     
     case 'q':
     break;
     
     default:
     cout << "Invalid Entry, Please try again" << endl;
     system("PAUSE");     
   }  
  }while (menu != 'q');
  return 0;
}

void print_menu()
{
      system("cls");
      cout << endl\
           << "\ta - Add a customer"<< endl\
           << "\td - Deposit money"<< endl\
           << "\tw - Withdraw money"<< endl\
           << "\ts - Show Account Information" << endl\
           << "\tq - Quit Application.\n\n" << endl;
      cout << "\tchoice: ";
}
