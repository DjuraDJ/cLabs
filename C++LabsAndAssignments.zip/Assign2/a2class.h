/*****************************************************************************
 * I Kyle Bauer, 000199229 certify that this material is my original work.   *
 * No other person's work has been used without due acknowledgement.         *
 *                                                                           *
 * Autor:       Kyle Bauer - 000199229                                       *
 * Course:      CO856                                                        *
 * Instructor:  N. Corkigian                                                 *
 * Description: CO856 Assignment2 Class header file                          *
 *****************************************************************************/
#include <iostream>
#include <string>
#include <stdlib.h>
#include <conio.h>
#include <fstream>

using namespace std;

struct  accounts
{
    long socid;
    int accid;
    float balance;
    string type;
    accounts *next;
};
class acclist
{
private:
    accounts *nfirst;
public:
    acclist()
    {  nfirst = NULL;}
    void nadditem(long s, int a, string t, float b);
    void ndisplay(long nsoc);
};

// Code adds item to front of linked list

void acclist::nadditem(long s, int a, string t, float b)
{
    accounts * newlink = new accounts;
    newlink -> socid = s;
    newlink -> accid = a;
    newlink -> type = t;
    newlink -> balance = b;
    newlink -> next = nfirst;
    nfirst = newlink;
}

void acclist::ndisplay(long nsoc)
{
    accounts *current = nfirst;
    while(current != NULL)
    {
    if (nsoc == (current -> socid))
    {
        cout << current->socid << "   " << current->accid <<
        "   " << current->type << "   " << current->balance << endl;
    }
    current = current ->next;
    }
}

struct  clientlink
{
    long socnum;
    string fstname, lstname, address, phone;
    clientlink *next;
};
class clientlist
{
private:
    clientlink *first;
    long nsocnum;
public:
    clientlist()
    {  first = NULL;}
    void additem(long s, string f, string l, string a, string p);
//    void deleteitem(long nsocnum);
    void display();
//    clientlink* getnext();
};

// Code adds item to front of linked list

void clientlist::additem(long s, string f, string l, string a, string p)
{
    clientlink * newlink = new clientlink;
    clientlink * current = first;

    newlink -> socnum = s;
    newlink -> fstname = f;
    newlink -> lstname = l;
    newlink -> address = a;
    newlink -> phone = p;
    newlink -> next = NULL;

    if (first == NULL)
    first = newlink;

    else{
    while (current != NULL)
    {
    if ((current -> lstname.at(0)) >= (newlink -> lstname.at(0)))
    {
        newlink -> next = current;
        first = newlink;
        break;
    }
    else if((current -> next) == NULL)
    {
         current -> next = newlink;
         current = newlink;
         break;
    }
    else if((current->next->lstname.at(0)) >= (newlink->lstname.at(0)))
    {
         newlink -> next = current->next;
         current -> next = newlink;
         break;
    }
    current = current -> next;
    }
    }
}


/*void clientlist::deleteitem(long delsocnum)
{
    clientlink * current = first;
    clientlink * prev;

    while (current != NULL)
    {
    if ((first -> socnum) == delsocnum)
    {
          cout << "First";
          system ("PAUSE");
          first -> current ->next;
          break;
    }
    else if ((current -> next) == NULL && (current -> socnum) == delsocnum)
    {
          cout << "Last";
          system("PAUSE");
          current = NULL;
          break;
    }
    else
    {
    cout << "NO RECORD FOUND" << endl;
    system("PAUSE");
    break;
    }
    current = current -> next;
    }
}*/

void clientlist::display()
{
    clientlink * current = first;
    while(current != NULL)
    {
        cout << current->socnum << "   " << current->fstname << "   "
        << current->lstname << "   " << current->address << "   " <<
        current->phone << endl;
        current = current -> next;
    }
    cout << "\n";
}

