//I, Djura Djurickovic, 000199229 certify that this material is my original work.
//No other person's work has been used without due acknowledgement.
//  Starting code for Part 1 - Lab # 4

#include <iostream>
#include <string>
#include <stdlib.h>

struct  link
{
    int stnum;
    string name;
    link *next;
};
class linklist
{
private:
    link *first;
public:
    linklist()
    {  first = NULL;}
    linklist &operator + (link &list) {
      this->additem(list.stnum,list.name);
      return *this;
    }
    friend ostream &operator<<(ostream &out, linklist &list);
    friend istream &operator>>(istream &in, link &list);
    void additem(int s, string n);
    void display();
};

// Code adds item to front of linked list

void linklist::additem(int s,string n)
{
    link * newlink = new link;
    link * current = first;

    newlink -> stnum = s;
    newlink -> name = n;
    newlink -> next = NULL;

    if (first == NULL)
    first = newlink;

    else{
    while (current != NULL)
    {
    if ((current -> stnum) >= (newlink -> stnum))
    {
        newlink -> next = current;
        first = newlink;
        break;
    }
    else if((current -> stnum) < (newlink -> stnum) && (current -> next) == NULL)
    {
         current -> next = newlink;
         current = newlink;
         break;
    }
    else if((current->next->stnum) >= (newlink->stnum))
    {
         newlink -> next = current->next;
         current -> next = newlink;
         break;
    }
    current = current -> next;
    }
    }
}

ostream &operator << (ostream &out, linklist &list)
{
   link * current = list.first;

   while (current != NULL)
   {
       out << current->stnum << "   " << current->name <<endl;
        current = current -> next;
   }
   cout << endl;
   return out;
}

istream &operator >> (istream &in, link &list) {

   in >> list.stnum >> list.name;
   return in;
}

void linklist::display()
{
    link * current = first;
    while(current != NULL)
    {
        cout << current->stnum << "   " << current->name <<endl;
        current = current -> next;
    }
    cout << endl;
}

int main()
{
    linklist mohawk;
    link overload;
    string choice = "y";
    mohawk.additem(1315,"Mary");
    mohawk.additem(1307,"John");
    mohawk.additem(1293,"Kim");
    mohawk.additem(1270,"Marty");
    mohawk.additem(1258,"Linda");
    mohawk.additem(1300,"Kyle");
    mohawk.display();
    while(choice !="n")
    {
    cout << "Would you like to enter a new record?(y/n): ";
    cin >> choice;
    if (choice == "y")
    {
        cout << "Please enter Student Number and Name: ";
        cin >> overload;
        mohawk + overload;
        cout << mohawk;
    }
    else
    break;
    }
    cin.ignore();
    cin.get();
    return 0;
}



