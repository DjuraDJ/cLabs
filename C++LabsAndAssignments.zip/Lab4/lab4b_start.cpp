//I, Djura Djurickovic certify that this material is my original work.
//No other person's work has been used without due acknowledgement.
#include <cmath>
#include <cstdio>
#include "winbgim.h"
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

//----------------------------------------------------------------------------
// Lab # 4 Starter Code - Use the DrawShape base class as is
// DO NOT MODIFY the methods that are in this class.
//----------------------------------------------------------------------------

// Draw Shape class

class DrawShape
{
private:
   int colour;
   static int count;
public:
   static int getCount() { return count; }
   int getColour()       { return colour; }

   DrawShape(int c) // All Shapes have a colour
   {
      colour = c;
      count++;      // Increment the count
   }
   ~DrawShape()     // Decrement count
   {
      count--;
   }

   // All shapes require a Label.
   // best to implement the label method in the base class.
   // Note the call to Area.  This calls the Area function in the 
   // actual shape object that has been instantiated.

   void label (int x, int y)
   {
      char s[20];
      sprintf (s, "%d", (int)Area());
      setcolor(WHITE);
      setbkcolor(BLACK);
      settextjustify(CENTER_TEXT, CENTER_TEXT);
      outtextxy(x, y, s);
   }
 
   // virtual functions - MUST be implemented in derived classes
   virtual double Area() = 0; 
   virtual void   Draw() = 0;
};

int DrawShape::count = 0;


class Circle : public DrawShape {

      private:
             int radius;
             int xCoord,yCoord;

      public:

      Circle(int c, int x, int y, int r) : DrawShape(c),
             xCoord(x), yCoord(y), radius(r)
             { }

      double Area() {

        double A;

        A = (3.14 * radius * radius);
        return A;

      }
      //Draws a circle
      void Draw() {

      setcolor(DrawShape::getColour());
      circle(xCoord,yCoord,radius);
      setfillstyle(1,DrawShape::getColour());
      floodfill(xCoord,yCoord,DrawShape::getColour());
      DrawShape::label(xCoord,yCoord);

     }
};


class Rect : public DrawShape {

      private:
             int size;
             int xCoord,yCoord;

      public:

      Rect(int c, int x=0, int y=0, int s=0) : DrawShape(c),
             xCoord(x), yCoord(y), size(s)
             { }

      double Area() {

        double A;
        A = ((size)*(size*2));
        return A;

      }
      //Draws a Rectangle
      void Draw() {

      setcolor(DrawShape::getColour());
      rectangle(xCoord,yCoord,xCoord+(size),yCoord+(size*2));
      setfillstyle(1,DrawShape::getColour());
      floodfill((xCoord+1),(yCoord+1),DrawShape::getColour());
      DrawShape::label((xCoord+size),(yCoord+size/2));

     }

};

class Square : public DrawShape {

      private:
             int size;
             int xCoord,yCoord;

      public:

      Square(int c, int x=0, int y=0, int s=0) : DrawShape(c),
             xCoord(x), yCoord(y), size(s)
             { }

      double Area() {

        double A;

        A = ((size)*(size));
        return A;

      }
      //Draws a Square
      void Draw() {

      setcolor(DrawShape::getColour());
      rectangle(xCoord,yCoord,xCoord+(size),yCoord+(size));
      setfillstyle(1,DrawShape::getColour());
      floodfill((xCoord+1),(yCoord+1),DrawShape::getColour());
      DrawShape::label((xCoord+size/2),(yCoord+size/2));

     }
};

class Ellpse : public DrawShape {

      private:
             int xradius,yradius;
             int xCoord,yCoord;

      public:

      Ellpse(int c, int x, int y, int xr, int yr) : DrawShape(c),
             xCoord(x), yCoord(y), xradius(xr*2), yradius(yr)
             { }

      double Area() {

        double A;

        A = (3.14 * (xradius*2) * (yradius*2));
        return A;

      }
      //Draws an Ellipse
      void Draw() {

      setcolor(DrawShape::getColour());
      ellipse(xCoord,yCoord,0,360,xradius,yradius);
      setfillstyle(1,DrawShape::getColour());
      floodfill((xCoord),(yCoord),DrawShape::getColour());
      DrawShape::label(xCoord,yCoord);

     }
};



int main() {

   int genNum(int);
   int gensize();
   int gencolour();

   DrawShape* shapes[100];
   char choice;
   int maxx, maxy;
   int sz,x,y,rad,colour,count,xrad,yrad;
   initwindow(700,700);
   maxx = getmaxx();
   maxy = getmaxy();
   settextstyle(GOTHIC_FONT, 0,1);
   outtextxy(1,1,"(s)Square (r)Rectangle (c)Circle (e)Ellipse (q)Quit");
   settextstyle(0,0,1);
   while (choice != 'q')
   {

   //Selects which object to draw
   choice = (char) getch( );
     switch(choice) {
     //Case Circle
          case 'c': {
            x = genNum(maxx);
            y = genNum(maxy);
            rad = gensize();
            colour = gencolour();
            count = DrawShape::getCount();
            shapes[count] = new Circle(colour,x,y,rad);
            shapes[count]->Draw();
            break;    }
      //Case Square
         case 's':  {
            x = genNum(maxx);
            y = genNum(maxy);
            sz = gensize()+gensize();
            colour = gencolour();
            count = DrawShape::getCount();
            shapes[count] = new Square(colour,x,y,sz);
            shapes[count]->Draw();
            break;    }
      //Case Rectangle
         case 'r':  {
            x = genNum(maxx);
            y = genNum(maxy);
            sz = gensize()+gensize();
            colour = gencolour();
            count = DrawShape::getCount();
            shapes[count] = new Rect(colour,x,y,sz);
            shapes[count]->Draw();
            break;    }
       //Case Ellipse
          case 'e': {
            x = genNum(maxx);
            y = genNum(maxy);
            xrad = gensize();
            yrad = gensize();
            colour = gencolour();
            count = DrawShape::getCount();
            shapes[count] = new Ellpse(colour,x,y,xrad,yrad);
            shapes[count]->Draw();
            break;    }

      }

   }

   return 0;
}

//Generates random co-ordinates
int genNum(int num) {

  srand(clock()*34567); //seeding the generator
  num = ((rand() % num) + 1);
  return num;

}

//Generates a number to determine the size of the graphic
int gensize() {

  int maxsize;

  srand(clock()*34665); //seeding the generator
  maxsize = ((rand() % 100) + 10);
  return maxsize;

}

//Randomly picks the colour
int gencolour() {

  int colour;


  srand( clock()*32423 ); //seed the random number generator
  colour = ((rand() % 15) + 1);
  return colour;

}

