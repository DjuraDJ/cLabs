﻿// I,Djura Djurickovic 000140392, certify that this material is my
// original work. No other person's work has been used without due
// acknowledgement and I have not made my work available to anyone else.

/*
 Test Data
Player       drily@canada.ca bluebirds
coach         oliviab@rogers.com seasiders
referee       asmith@gmail.com  brewers
Admin         ghouse@gmail.com  cuddy
No Access     akhd@gmail.com             asdas
 
 
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Services;
using System.Web.Configuration;
using System.Data.SqlClient;


public partial class Default2 : System.Web.UI.Page
{
    /// <summary>
    /// sets focus
    /// </summary>
    /// <param name="sender">page load</param>
    /// <param name="e">sender,e</param>
    protected void Page_Load(object sender, EventArgs e)
    {
        SetFocus(Login1.FindControl("UserName"));
    }
    /// <summary>
    /// holds season variables and authenticated 
    /// </summary>
    /// <param name="sender">login1_authenticate</param>
    /// <param name="e">sender,e</param>
    protected void Login1_Authenticate(object sender, AuthenticateEventArgs e)
    {
        e.Authenticated = true;

        try
        {


            HASC_Authentication hascAuth = new HASC_Authentication();

            bool authenticated = hascAuth.Authenticate(Login1.UserName, Login1.Password);

            //String result = hascAuth.Authenticate(Login1.UserName,Login1.Password);
            e.Authenticated = false;
            if (authenticated)
            {

                String role = hascAuth.getRole();
                int personID = hascAuth.getID();

                Session["HascID"] = personID;
                Session["role"] = role;
                Session["name"] = hascAuth.getName();

                e.Authenticated = true;
            }
            else
            {
                lblResult.Text = "no access";
                //Response.Redirect("unauthorization.aspx");
            }

        }
        catch
        {
            lblResult.Text = "no access";
        }
    }
    /// <summary>
    /// sets role and redirect to correct page 
    /// </summary>
    /// <param name="sender">Login1 loggedIN</param>
    /// <param name="e">sender,e</param>
    protected void Login1_LoggedIn(object sender, EventArgs e)
    {


        switch ((string)Session["role"])
        {
            case "Admin":
                Response.Redirect("~/protected/player.aspx");
                break;
            case "Coach":
                Response.Redirect("~/protected/coach.aspx");
                break;
            case "Referee":
                Response.Redirect("~/protected/referee.aspx");
                break;
            case "Player":
                Response.Redirect("~/protected/player.aspx");
                break;
            default:
                break;
        }
    }
}