﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
 {
    /// <summary>
    /// chechs if coach or admin
    /// </summary>
    /// <param name="sender">pageload</param>
    /// <param name="e">e,sender</param>
    protected void Page_Load(object sender, EventArgs e)
    {
        if ((string)Session["role"] != "Coach" && (string)Session["role"] != "Admin")
        {
            Response.Redirect("../unauthorization.aspx");
        }
        lblRole.Text = "Greeting " + (string)Session["role"] + " " + (string)Session["name"];
     
    }
}