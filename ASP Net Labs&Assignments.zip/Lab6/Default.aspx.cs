﻿// I,Djura Djurickovic 000140392, certify that this material is my
// original work. No other person's work has been used without due
// acknowledgement and I have not made my work available to anyone else.
/*
 Test Data
Player       drily@canada.ca bluebirds
coach         oliviab@rogers.com seasiders
referee       asmith@gmail.com  brewers
Admin         ghouse@gmail.com  cuddy
No Access     akhd@gmail.com    asdas
 
 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
}