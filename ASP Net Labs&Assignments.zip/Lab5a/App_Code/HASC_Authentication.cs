﻿// I,Djura Djurickovic 000140392, certify that this material is my
// original work. No other person's work has been used without due
// acknowledgement and I have not made my work available to anyone else.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Configuration;
using System.Data.SqlClient;

/// <summary>
/// Summary description for WebService
/// </summary>
[WebService(Namespace = "http://HASC_Authentication.cs/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
// [System.Web.Script.Services.ScriptService]
public class HASC_Authentication : System.Web.Services.WebService {

    public HASC_Authentication () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }
    /// <summary>
    /// 
    /// </summary>
    /// <param name="email">authenticate </param>
    /// <param name="password">String email,password</param>
    /// <returns></returns>
    [WebMethod]
    public string Authenticate(String email,String password)
    {
        try { 
        SqlConnection connection = new SqlConnection(WebConfigurationManager.ConnectionStrings["HASC"].ConnectionString);
        SqlCommand command = new SqlCommand(
         "SELECT * FROM Persons WHERE Email = @Email AND UserPassword = @UserPassword;",
          connection);

        command.Parameters.AddWithValue("@Email", email);
        command.Parameters.AddWithValue("@UserPassword", password);
        connection.Open();

        string accessLevel;
        string personID;
        SqlDataReader reader = command.ExecuteReader();
        // admin, coach, player or referee
        
        if (reader.HasRows)
        {
            reader.Read();

            bool isPlayer = (bool)reader["Player"];
            bool isCoach = (bool)reader["Coach"];
            bool isAdmin = (bool)reader["Administrator"];
            bool isRef = (bool)reader["Referee"];

            personID = reader["PersonID"].ToString();

            if (isPlayer) {
                accessLevel = "Player";
            }
            else if (isCoach) {
                accessLevel = "Coach";
            }
            else if (isAdmin)
            {
                accessLevel = "Admin";
            }
            else if (isRef)
            {
                accessLevel = "Referee";
            }
            else {return "No Access";}
                



        }
        else
        {
            return "No Access";
        }



        reader.Close();



        return accessLevel+","+personID;
        }catch {
         return "noaccess";
        } 

    }
    
}

    
       
 
 
  

       //     SqlDataReader reader = command.ExecuteReader();

       //     if (reader.HasRows)
       //     {

       //         while (reader.Read())
       //         {
       //     reader["DivisionID"];

       //             //update.Parameters["@TeamID"].Value = c;
       //             //update.Parameters["@PlayerID"].Value = reader["PlayerID"];

       //             //update.ExecuteNonQuery();
       //         }
       //     }
       //     else
       //     {
       //         Console.WriteLine("No rows found.");
       //     }
       //     reader.Close();
                                                                       
       //// }