﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Teams : System.Web.UI.Page
{
    public String[] teamTables;
    public int divisionID;
    public int counter = 0;
    /// <summary>
    /// creates table and display data
    /// </summary>
    /// <param name="sender">pageloader</param>
    /// <param name="e">sender</param>
    protected void Page_Load(object sender, EventArgs e)
    {
        divisionID = int.Parse(Session["Division"].ToString());
        lblDivision.Text = Session["DivisionName"].ToString();

        SqlConnection connection = new SqlConnection(SqlDataSource1.ConnectionString);
        SqlCommand command = new SqlCommand(
      "SELECT FirstName,LastName, TeamID,SkillLevel,Email,Phone FROM Players WHERE DivisionID = @DivisionID ORDER BY SkillLevel DESC;",
      connection);
        connection.Open();
     
        command.Parameters.Add("@DivisionID", System.Data.SqlDbType.Int);
        command.Parameters["@DivisionID"].Value = divisionID;

        SqlDataReader reader = command.ExecuteReader();

        teamTables = new String[]{"","","","",""};

        if (reader.HasRows)
        {
        //    teamTables[table] += "<tr>" +
        //       "<th>Player</th>"+
        //       "<th>Skill</th>"+
        //       "<th>Email</th>" +
        //       "<th>Phone</th>" +
        //      "</tr>";

            while (reader.Read())
            {
                int teamID = (int)reader["TeamID"];               
                int table = teamID - 1 - (divisionID-1)*4;

                teamTables[table] += "<tr>"+
                 "<td>"+reader["FirstName"]+","+reader["LastName"]+"</td>"+
               
                "<td>"+reader["SkillLevel"]+"</td>"+
                "<td>" + reader["Email"] + "</td>" +

                "<td>" + reader["Phone"] + "</td>"+
                "</tr>";
            }
        }
        else
        {
            Console.WriteLine("No rows found.");
        }
        reader.Close();
                       


    }
}