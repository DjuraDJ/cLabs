﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender">PageLoad</param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    /// <summary>
    ///  use two connections while one is reading the records. 
    /// </summary>
    /// <param name="Button1_Click"></param>
    /// <param name="e">Sender</param>
    protected void Button1_Click(object sender, EventArgs e)
    {
        Session["Division"] = ddlDivison.SelectedValue;
        Session["DivisionName"] = "Division: " + ddlDivison.SelectedItem.Text;
     
        SqlConnection connection = new SqlConnection(SDSDivison.ConnectionString);
        // use two connections while one is reading the records. 
        SqlConnection connection2 = new SqlConnection(SDSDivison.ConnectionString);
        TeamSorter(connection, connection2);
        Response.Redirect("Teams.aspx");
    }
    /// <summary>
    /// sorts the teams and updates 
    /// </summary>
    /// <param name="connection">TeamSorter</param>
    /// <param name="connection2">connection</param>
    protected void TeamSorter(SqlConnection connection, SqlConnection connection2)
    {
        //using (connection) {
            SqlCommand command = new SqlCommand(
          "SELECT PlayerID , DivisionID,TeamID,SkillLevel FROM Players ORDER BY DivisionID,SkillLevel DESC;",
          connection);
            SqlCommand update = new SqlCommand(
         "UPDATE Players SET TeamID = @TeamID WHERE PlayerID = @PlayerID",
         connection2);
            
            
            connection.Open();
            connection2.Open();
            update.Parameters.Add("@TeamID",System.Data.SqlDbType.Int);
            update.Parameters.Add("@PlayerID", System.Data.SqlDbType.Int);

            SqlDataReader reader = command.ExecuteReader();

            if (reader.HasRows)
            {
                int count = 0;
                while (reader.Read())
                {
                   // Console.WriteLine("{0}\t{1}", reader.GetInt32(0),
                     //   reader.GetString(1));
                    int a=4*((int)reader["DivisionID"]-1);
                    int b=count%4;
                    int c=b+a+1;



                    update.Parameters["@TeamID"].Value = c;
                    update.Parameters["@PlayerID"].Value = reader["PlayerID"];
                    count++;
                    update.ExecuteNonQuery();
                }
            }
            else
            {
                Console.WriteLine("No rows found.");
            }
            reader.Close();
                                                                       
       // }
    }
}