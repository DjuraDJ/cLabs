﻿ // I,Djura Djurickovic 000140392, certify that this material is my
 // original work. No other person's work has been used without due
 // acknowledgement and I have not made my work available to anyone else. 


using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GuessGame
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        Random randNum = new Random();
        private int maxNum = 25;  // maxium number 25 is assigned 
        private int minNum = 1;  // min number 1 is assigned
       
        /// <summary>
        /// Start the game
        /// </summary>
        /// <param name="sender">Page</param>
        /// <param name="e">Event data</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //txtBoxGuess.Enabled = false;
               // btnGuess.Visible = false;
               // btnStop.Visible = false;
                //btnStart.Visible = false;
                btnStart_Click(sender, e);
            }
        }
        // once the start is clicked start guess box and botton go visiable and focus is set
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender">btnStart</param>
        /// <param name="e"></param>
        protected void btnStart_Click(object sender, EventArgs e)
        {
            btnStart.Visible = false;
            txtBoxGuess.ReadOnly = false;
            txtBoxGuess.Focus();
            btnGuess.Visible = true;
            btnStop.Visible = true;
            txtBoxGuess.Text = "";
            lblMsg.Text = "";

            // random number is put in the session [answer] variable and counter is set to zero
            Session["answer"] = randNum.Next(minNum,maxNum+1);
            Session["counter"]=0;
            // converted numbers to string to display.
            lblAnswer.Text = Session["answer"].ToString();
            lblCounter.Text = Session["counter"].ToString();
        }
        // following checks the guess and makes sure it is with in range
        protected void btnGuess_Click(object sender, EventArgs e)
        {
            txtBoxGuess.Focus();

            Session["counter"] = (int)Session["counter"] + 1;
            lblCounter.Text = Session["counter"].ToString();

            int guess;
            // checks to see if guess variable is vaild and if not msg is displayed 
            if (!Int32.TryParse(txtBoxGuess.Text, out guess))
            {
                lblMsg.Text = "The value is not vaild Try again please";
            } else if(guess > maxNum || guess < minNum){
                 lblMsg.Text = "This value is out of range try again please";
            }else if(guess<(int)Session["answer"]){
                lblMsg.Text = "Your Answer is to low try again";
            }else if(guess>(int)Session["answer"]){
                lblMsg.Text = "Your Answer is to High try again";
            }else if (guess == (int)Session["answer"]){
                
                lblMsg.Text = "Correct !  The amount of guess was "+ Session["counter"].ToString();
               btnStop_Click(sender, e);
             
                  
                
            }


        }
        // once pressed the start and stop botton become visiable and start in focus.
        protected void btnStop_Click(object sender, EventArgs e)
        {
            btnStart.Visible = true;
            //txtBoxGuess.Enabled = false;
            txtBoxGuess.ReadOnly = false;
            btnStop.Visible = false;
           // lblMsg.Text = "Correct answer was " + Session["answer"].ToString();
            btnStart.Focus();
            btnGuess.Visible = false;   
        }
    }
}