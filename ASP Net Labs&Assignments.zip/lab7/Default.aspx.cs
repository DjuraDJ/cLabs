﻿// I, Djura Djurickovic 000140392, certify that this material is my
// original work. No other person's work has been used without due
// acknowledgement and I have not made my work available to anyone else.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Configuration;
using System.Data.SqlClient;
using System.Web.UI.DataVisualization.Charting;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    /// <summary>
    /// connects to database and creates x and y axis
    /// referneces to nursing unit
    /// </summary>
    /// <param name="sender">chartload</param>
    /// <param name="e">sender,e</param>
    protected void Chart1_Load(object sender, EventArgs e)
    {
        string con_string = WebConfigurationManager.ConnectionStrings["CHDBConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(con_string);

        SqlCommand cmd = new SqlCommand("SELECT SUBSTRING(NursingUnitID, 1, 1) AS Floor, COUNT(*) AS Patients FROM Admissions WHERE SUBSTRING(NursingUnitID, 1, 1) IN ('1', '2', '3') AND DischargeDate IS NULL GROUP BY SUBSTRING(NursingUnitID, 1, 1)",con);
            try{
                using (con) {
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    
                    Chart1.Series["Series1"].Points.DataBindXY(reader, "Floor", reader, "Patients");
                }
                foreach (DataPoint p in Chart1.Series["Series1"].Points)
                {
                    p.Url = "references_nursing_units.aspx?floor=" + p.AxisLabel;
                }
            } 
            catch(Exception ex){
               // Label1.Text = ex.ToString();
            }
  
    }
}