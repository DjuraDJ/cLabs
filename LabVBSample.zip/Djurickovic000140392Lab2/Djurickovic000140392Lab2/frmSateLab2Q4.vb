﻿' Purpose: To Dispaly the States once the button is clicked
' Name: Djura Djurickovic 
'Date Sept 21 2011
'Authorship I Djura Djurickovic 000140392 certify that this material is
' my original work. Source code provided by the course text publisher was  
' modified entirely by me.  No other person's work has been used 
' without due acknowledgement. I have not made my work 
' available to anyone else.




Public Class frmSateLab2Q4

    Private Sub btnVirginia_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnVirginia.Click
        lblAbbrev.TextAlign = ContentAlignment.MiddleCenter     'aligns text to center of label 
        lblAbbrev.Text = "VA"                                  'Displays abbreviation of state after button clicked 
    End Sub




    Private Sub btnNorthCarol_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNorthCarol.Click
        lblAbbrev.TextAlign = ContentAlignment.MiddleCenter                  'aligns text to center of label
        lblAbbrev.Text = "NC"                                             'Displays abbreviation of state after button clicked 
    End Sub

    Private Sub btnSouthCarol_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSouthCarol.Click
        lblAbbrev.TextAlign = ContentAlignment.MiddleCenter                 'aligns text to center of label
        lblAbbrev.Text = "SC"                                                'Displays abbreviation of state after button clicked 
    End Sub

    Private Sub btnGeorgia_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGeorgia.Click
        lblAbbrev.TextAlign = ContentAlignment.MiddleCenter                 'aligns text to center of label
        lblAbbrev.Text = "GA"                                               'Displays abbreviation of state after button clicked 
    End Sub

    Private Sub btnAlabam_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAlabam.Click
        lblAbbrev.TextAlign = ContentAlignment.MiddleCenter                 'aligns text to center of label
        lblAbbrev.Text = "AL"                                              'Displays abbreviation of state after button clicked 
    End Sub

    Private Sub btnFlordia_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFlordia.Click
        lblAbbrev.TextAlign = ContentAlignment.MiddleCenter                   'aligns text to center of label
        lblAbbrev.Text = "FL"                                                'Displays abbreviation of state after button clicked 
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()                                          'Close form 
    End Sub
End Class