	watchID = null;
	countMe = 0;

	var c=document.getElementById("canvas");
	var ctx=c.getContext("2d");
		
	var dice =
	[
		'filler',
		new Image(),
		new Image(),
		new Image(),
		new Image(),
		new Image(),
		new Image()
	]
	
	dice[1].src='img/d1.png'
	dice[2].src='img/d2.png'
	dice[3].src='img/d3.png'
	dice[4].src='img/d4.png'
	dice[5].src='img/d5.png'
	dice[6].src='img/d6.png'
	
	var lastX = 0;
	var spinCount = 0;
	
	var spinLimit = 7;
	var shakeFrequencyLimit = 20 // Minimum time between shakes - 30 = 30 seconds
	var shakeResistance = 3; // Higher number means harder to shake
	var spinDelay = 250 // milliseconds between dice rolls
	
	
	var timerLastShake = shakeFrequencyLimit;
	
	$(document).ready(function()
	{  
		console.log('Document Ready');
		document.addEventListener('deviceready',startWatch,true)
		showDice();
	});
     
	function onDeviceReady() {
     	startWatch();
    }
	
	function startWatch() {
		console.log('Start Watch');
        var options = { frequency: 100 };
        watchID = navigator.accelerometer.watchAcceleration(onSuccess, onError, options);
    }

    function stopWatch() {
			console.log('Stop Watch');
        if (watchID) {  
            navigator.accelerometer.clearWatch(watchID);
	 		countMe = 0;
            watchID = null;
        }
    }

    function onSuccess(acceleration) {
			console.log('Accelerometer Success');
			timerLastShake++;
			
			_x = roundNumber(acceleration.x,3);
			_y = roundNumber(acceleration.y,3);
			_z = roundNumber(acceleration.z,3);
			
			if (getDifference(_x) >  shakeResistance && checkShake())
			{
				shake();
			}

			$('#x').text(_x);
			$('#y').text(_y);
			$('#z').text(_z);
			$('#t').text(countMe++);					
						
			lastX = _x;
	}
	//rounds number to number of decimal places 
	function roundNumber (number, decimalplaces) {
		return  Math.round(number * Math.pow(10,decimalplaces)) / Math.pow(10,decimalplaces);
	}

    // onError: Failed to get the acceleration
    //
	
	function getDifference(x)
	{
		var tempX1 = lastX += 100;
		var tempX2 = x += 100;

		//console.log(Math.abs(tempX1 - tempX2));
		
		return Math.abs(tempX1 - tempX2);
	}
	
	
	
    function onError() {
       console.log('Accelerometer Error');
    }
	
	function checkShake()
	{
		return (timerLastShake > shakeFrequencyLimit);
	}
	
	function shake(){
		timerLastShake = 0;
		spinCount = 0;
		
		spin();
		
		//showDice(rollDie(),rollDie());
		//alert("shake");
	}
	
	
	function spin()
	{
		spinCount++;
		
		showDice();
		
		if (spinLimit > spinCount)
		{
			setTimeout(spin,spinDelay);
		}
	}

	function showDice(d1,d2)
	{
		var d1 = Math.floor(Math.random() * (6 - 1 + 1)) + 1;
		var d2 = Math.floor(Math.random() * (6 - 1 + 1)) + 1;
		
		//canvas drawing
		c.width = c.width;

		ctx.drawImage(dice[d1],10,10,75,75);	
		ctx.drawImage(dice[d2],100,10,75,75);		
	}	
	
	