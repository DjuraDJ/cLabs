﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmAutoCost
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblDLoan = New System.Windows.Forms.Label()
        Me.lblDIns = New System.Windows.Forms.Label()
        Me.lblDTires = New System.Windows.Forms.Label()
        Me.lblTotmonth = New System.Windows.Forms.Label()
        Me.LbltotAnnual = New System.Windows.Forms.Label()
        Me.btnMonth = New System.Windows.Forms.Button()
        Me.btnTotAnnual = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblDmonth = New System.Windows.Forms.Label()
        Me.TxtLoan = New System.Windows.Forms.TextBox()
        Me.lblDgas = New System.Windows.Forms.Label()
        Me.lblDOil = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TxtTires = New System.Windows.Forms.TextBox()
        Me.TxtOil = New System.Windows.Forms.TextBox()
        Me.TxtGas = New System.Windows.Forms.TextBox()
        Me.TxtInsure = New System.Windows.Forms.TextBox()
        Me.TxtMain = New System.Windows.Forms.TextBox()
        Me.GrBxAuto = New System.Windows.Forms.GroupBox()
        Me.GrBxTotCost = New System.Windows.Forms.GroupBox()
        Me.GrpBxButtons = New System.Windows.Forms.GroupBox()
        Me.GrBxAuto.SuspendLayout()
        Me.GrBxTotCost.SuspendLayout()
        Me.GrpBxButtons.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblDLoan
        '
        Me.lblDLoan.Location = New System.Drawing.Point(8, 28)
        Me.lblDLoan.Name = "lblDLoan"
        Me.lblDLoan.Size = New System.Drawing.Size(97, 22)
        Me.lblDLoan.TabIndex = 0
        Me.lblDLoan.Text = "Loan Payment"
        Me.lblDLoan.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblDIns
        '
        Me.lblDIns.Location = New System.Drawing.Point(4, 77)
        Me.lblDIns.Name = "lblDIns"
        Me.lblDIns.Size = New System.Drawing.Size(97, 22)
        Me.lblDIns.TabIndex = 2
        Me.lblDIns.Text = "Insurance "
        Me.lblDIns.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblDTires
        '
        Me.lblDTires.Location = New System.Drawing.Point(4, 129)
        Me.lblDTires.Name = "lblDTires"
        Me.lblDTires.Size = New System.Drawing.Size(97, 22)
        Me.lblDTires.TabIndex = 5
        Me.lblDTires.Text = "Tires"
        Me.lblDTires.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTotmonth
        '
        Me.lblTotmonth.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.lblTotmonth.Location = New System.Drawing.Point(125, 46)
        Me.lblTotmonth.Name = "lblTotmonth"
        Me.lblTotmonth.Size = New System.Drawing.Size(97, 22)
        Me.lblTotmonth.TabIndex = 7
        Me.lblTotmonth.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LbltotAnnual
        '
        Me.LbltotAnnual.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.LbltotAnnual.Location = New System.Drawing.Point(337, 46)
        Me.LbltotAnnual.Name = "LbltotAnnual"
        Me.LbltotAnnual.Size = New System.Drawing.Size(97, 22)
        Me.LbltotAnnual.TabIndex = 8
        Me.LbltotAnnual.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnMonth
        '
        Me.btnMonth.Location = New System.Drawing.Point(130, 36)
        Me.btnMonth.Name = "btnMonth"
        Me.btnMonth.Size = New System.Drawing.Size(88, 48)
        Me.btnMonth.TabIndex = 10
        Me.btnMonth.Text = "Calculate Total Monthly " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Cost"
        Me.btnMonth.UseVisualStyleBackColor = True
        '
        'btnTotAnnual
        '
        Me.btnTotAnnual.Location = New System.Drawing.Point(18, 36)
        Me.btnTotAnnual.Name = "btnTotAnnual"
        Me.btnTotAnnual.Size = New System.Drawing.Size(99, 48)
        Me.btnTotAnnual.TabIndex = 9
        Me.btnTotAnnual.Text = "Calculate Total " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Annual Cost"
        Me.btnTotAnnual.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(240, 36)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(99, 48)
        Me.btnClear.TabIndex = 11
        Me.btnClear.Text = "Clear "
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(358, 36)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(84, 48)
        Me.btnClose.TabIndex = 12
        Me.btnClose.Text = "Exit"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(231, 41)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(100, 28)
        Me.Label1.TabIndex = 20
        Me.Label1.Text = "Annual Cost"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblDmonth
        '
        Me.lblDmonth.Location = New System.Drawing.Point(19, 46)
        Me.lblDmonth.Name = "lblDmonth"
        Me.lblDmonth.Size = New System.Drawing.Size(100, 23)
        Me.lblDmonth.TabIndex = 21
        Me.lblDmonth.Text = "Total Monthly "
        '
        'TxtLoan
        '
        Me.TxtLoan.Location = New System.Drawing.Point(116, 30)
        Me.TxtLoan.Name = "TxtLoan"
        Me.TxtLoan.Size = New System.Drawing.Size(102, 20)
        Me.TxtLoan.TabIndex = 1
        '
        'lblDgas
        '
        Me.lblDgas.Location = New System.Drawing.Point(241, 28)
        Me.lblDgas.Name = "lblDgas"
        Me.lblDgas.Size = New System.Drawing.Size(97, 22)
        Me.lblDgas.TabIndex = 3
        Me.lblDgas.Text = "Gas"
        Me.lblDgas.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblDOil
        '
        Me.lblDOil.Location = New System.Drawing.Point(241, 71)
        Me.lblDOil.Name = "lblDOil"
        Me.lblDOil.Size = New System.Drawing.Size(97, 22)
        Me.lblDOil.TabIndex = 4
        Me.lblDOil.Text = "Oil"
        Me.lblDOil.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(241, 127)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(97, 22)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "Maintenace"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TxtTires
        '
        Me.TxtTires.Location = New System.Drawing.Point(116, 131)
        Me.TxtTires.Name = "TxtTires"
        Me.TxtTires.Size = New System.Drawing.Size(102, 20)
        Me.TxtTires.TabIndex = 3
        '
        'TxtOil
        '
        Me.TxtOil.Location = New System.Drawing.Point(344, 71)
        Me.TxtOil.Name = "TxtOil"
        Me.TxtOil.Size = New System.Drawing.Size(102, 20)
        Me.TxtOil.TabIndex = 5
        '
        'TxtGas
        '
        Me.TxtGas.Location = New System.Drawing.Point(344, 30)
        Me.TxtGas.Name = "TxtGas"
        Me.TxtGas.Size = New System.Drawing.Size(102, 20)
        Me.TxtGas.TabIndex = 4
        '
        'TxtInsure
        '
        Me.TxtInsure.Location = New System.Drawing.Point(116, 79)
        Me.TxtInsure.Name = "TxtInsure"
        Me.TxtInsure.Size = New System.Drawing.Size(102, 20)
        Me.TxtInsure.TabIndex = 2
        '
        'TxtMain
        '
        Me.TxtMain.Location = New System.Drawing.Point(344, 129)
        Me.TxtMain.Name = "TxtMain"
        Me.TxtMain.Size = New System.Drawing.Size(102, 20)
        Me.TxtMain.TabIndex = 6
        '
        'GrBxAuto
        '
        Me.GrBxAuto.Controls.Add(Me.TxtMain)
        Me.GrBxAuto.Controls.Add(Me.TxtInsure)
        Me.GrBxAuto.Controls.Add(Me.TxtGas)
        Me.GrBxAuto.Controls.Add(Me.TxtOil)
        Me.GrBxAuto.Controls.Add(Me.TxtTires)
        Me.GrBxAuto.Controls.Add(Me.Label6)
        Me.GrBxAuto.Controls.Add(Me.lblDTires)
        Me.GrBxAuto.Controls.Add(Me.lblDOil)
        Me.GrBxAuto.Controls.Add(Me.lblDgas)
        Me.GrBxAuto.Controls.Add(Me.lblDIns)
        Me.GrBxAuto.Controls.Add(Me.TxtLoan)
        Me.GrBxAuto.Controls.Add(Me.lblDLoan)
        Me.GrBxAuto.Location = New System.Drawing.Point(12, 22)
        Me.GrBxAuto.Name = "GrBxAuto"
        Me.GrBxAuto.Size = New System.Drawing.Size(481, 209)
        Me.GrBxAuto.TabIndex = 22
        Me.GrBxAuto.TabStop = False
        Me.GrBxAuto.Text = "AutoMobile Costs"
        '
        'GrBxTotCost
        '
        Me.GrBxTotCost.Controls.Add(Me.lblTotmonth)
        Me.GrBxTotCost.Controls.Add(Me.lblDmonth)
        Me.GrBxTotCost.Controls.Add(Me.Label1)
        Me.GrBxTotCost.Controls.Add(Me.LbltotAnnual)
        Me.GrBxTotCost.Location = New System.Drawing.Point(12, 246)
        Me.GrBxTotCost.Name = "GrBxTotCost"
        Me.GrBxTotCost.Size = New System.Drawing.Size(470, 128)
        Me.GrBxTotCost.TabIndex = 23
        Me.GrBxTotCost.TabStop = False
        Me.GrBxTotCost.Text = "Total Monthly Annual Cost"
        '
        'GrpBxButtons
        '
        Me.GrpBxButtons.Controls.Add(Me.btnTotAnnual)
        Me.GrpBxButtons.Controls.Add(Me.btnClose)
        Me.GrpBxButtons.Controls.Add(Me.btnClear)
        Me.GrpBxButtons.Controls.Add(Me.btnMonth)
        Me.GrpBxButtons.Location = New System.Drawing.Point(16, 397)
        Me.GrpBxButtons.Name = "GrpBxButtons"
        Me.GrpBxButtons.Size = New System.Drawing.Size(465, 116)
        Me.GrpBxButtons.TabIndex = 24
        Me.GrpBxButtons.TabStop = False
        Me.GrpBxButtons.Text = "Calculation "
        '
        'FrmAutoCost
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(523, 565)
        Me.Controls.Add(Me.GrpBxButtons)
        Me.Controls.Add(Me.GrBxTotCost)
        Me.Controls.Add(Me.GrBxAuto)
        Me.Name = "FrmAutoCost"
        Me.Text = "Automobile Costs "
        Me.GrBxAuto.ResumeLayout(False)
        Me.GrBxAuto.PerformLayout()
        Me.GrBxTotCost.ResumeLayout(False)
        Me.GrpBxButtons.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents lblDLoan As System.Windows.Forms.Label
    Friend WithEvents lblDIns As System.Windows.Forms.Label
    Friend WithEvents lblDTires As System.Windows.Forms.Label
    Friend WithEvents lblTotmonth As System.Windows.Forms.Label
    Friend WithEvents LbltotAnnual As System.Windows.Forms.Label
    Friend WithEvents btnMonth As System.Windows.Forms.Button
    Friend WithEvents btnTotAnnual As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblDmonth As System.Windows.Forms.Label
    Friend WithEvents TxtLoan As System.Windows.Forms.TextBox
    Friend WithEvents lblDgas As System.Windows.Forms.Label
    Friend WithEvents lblDOil As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents TxtTires As System.Windows.Forms.TextBox
    Friend WithEvents TxtOil As System.Windows.Forms.TextBox
    Friend WithEvents TxtGas As System.Windows.Forms.TextBox
    Friend WithEvents TxtInsure As System.Windows.Forms.TextBox
    Friend WithEvents TxtMain As System.Windows.Forms.TextBox
    Friend WithEvents GrBxAuto As System.Windows.Forms.GroupBox
    Friend WithEvents GrBxTotCost As System.Windows.Forms.GroupBox
    Friend WithEvents GrpBxButtons As System.Windows.Forms.GroupBox
End Class
