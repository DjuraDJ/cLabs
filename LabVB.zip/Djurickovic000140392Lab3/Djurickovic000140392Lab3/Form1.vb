﻿'Purpose to Load other forms throw button click
'I Djura Djurickovic 000140392 certify that this material is
'my original work. Source code provided by the course text publisher was  
'modified entirely by me.  No other person's work has been used 
'without due acknowledgement. I have not made my work 
'available to anyone else.



Public Class frmLab3


    Private Sub btnRev_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRev.Click
        'loads form revenue
        frmRevenue.Show()
    End Sub

    Private Sub BtnAutoMobile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnAutoMobile.Click
        'loads automobile cost form
        FrmAutoCost.Show()
    End Sub
End Class
