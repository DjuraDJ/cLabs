﻿'Purpose : Calculate monthly and Annual cost of Autombile 
'I Djura Djurickovic 000140392 certify that this material is
'my original work. Source code provided by the course text publisher was  
'modified entirely by me.  No other person's work has been used 
'without due acknowledgement. I have not made my work 
'available to anyone else.




Public Class FrmAutoCost

    Dim DectotMonCost As Decimal  ' decloration 

    'close form 
    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub


    Private Sub FrmAutoCost_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        MessageBox.Show("Prepare to see the Automobile Cost!")  'msg displayed before form loads
    End Sub

    Private Sub btnMonth_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMonth.Click

        'try is used to make sure that none of the text box are left empty
        Try
            DectotMonCost = CDec(TxtGas.Text) + CDec(TxtInsure.Text) + CDec(TxtLoan.Text) + CDec(TxtMain.Text) + CDec(TxtOil.Text) + CDec(TxtTires.Text)  'adds the bills up to get monthly bill
            lblTotmonth.Text = DectotMonCost.ToString("c")         ' converts to string to display in label


        Catch
            MessageBox.Show("All input must be a Valid Numeric Value")

        End Try

    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        TxtGas.Clear()
        TxtInsure.Clear()
        TxtLoan.Clear()
        TxtMain.Clear()                 ' clears the text box after the clear button is clicked
        TxtOil.Clear()
        TxtGas.Clear()
        TxtTires.Clear()


        TxtLoan.Focus()            ' sets focus back to loan payment text box

    End Sub

    Private Sub btnTotAnnual_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTotAnnual.Click


        'Decloration 
        Dim DecTotAnnual As Decimal


        DecTotAnnual = DectotMonCost * 12  'multiplys the monthly bills by 12 to get annual cost
        LbltotAnnual.Text = DecTotAnnual.ToString("c")    ' converts annual cost to a string


    End Sub
End Class